package cat.uvic.teknos.shoeshop.clients.utils;

import cat.uvic.teknos.shoeshop.clients.exceptions.ConsoleClientException;
import cat.uvic.teknos.shoeshop.clients.exceptions.RequestException;
import com.fasterxml.jackson.databind.ObjectMapper;
import rawhttp.core.RawHttp;

import java.io.IOException;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.nio.charset.StandardCharsets;

public class RestClientImpl implements RestClient {
    private final String host;
    private final int port;
    private static final int SOCKET_TIMEOUT = 10000; // 10 segons
    private final RawHttp rawHttp;
    private final ObjectMapper mapper;

    public RestClientImpl(String host, int port) {
        this.host = host;
        this.port = port;
        this.rawHttp = new RawHttp();
        this.mapper = new ObjectMapper();
        System.out.println("RestClient inicialitzat amb host: " + host + ", port: " + port);
    }

    @Override
    public <T> T get(String path, Class<T> returnType) throws RequestException {
        return execRequest("GET", path, null, returnType);
    }

    @Override
    public <T> T[] getAll(String path, Class<T[]> returnType) throws RequestException {
        return execRequest("GET", path, null, returnType);
    }

    @Override
    public void post(String path, String body) throws RequestException {
        execRequest("POST", path, body, Void.class);
    }

    @Override
    public void put(String path, String body) throws RequestException {
        execRequest("PUT", path, body, Void.class);
    }

    @Override
    public void delete(String path, String body) throws RequestException {
        execRequest("DELETE", path, body, Void.class);
    }

    private <T> T execRequest(String method, String path, String body, Class<T> returnType) throws RequestException {
        if (body == null) {
            body = "";
        }

        try (Socket socket = new Socket(host, port)) {
            socket.setSoTimeout(SOCKET_TIMEOUT);

            String requestString = String.format(
                    "%s http://%s:%d/%s HTTP/1.1\r\n" +
                            "Host: %s\r\n" +
                            "Content-Type: application/json\r\n" +
                            "Accept: application/json\r\n" +
                            "Content-Length: %d\r\n" +
                            "Connection: close\r\n\r\n" +
                            "%s",
                    method, host, port, path.startsWith("/") ? path.substring(1) : path, host, body.length(), body);

            var request = rawHttp.parseRequest(requestString);
            request.writeTo(socket.getOutputStream());

            var response = rawHttp.parseResponse(socket.getInputStream()).eagerly();

            //if (response.getStatusCode() != 200) {
            //    throw new RequestException("Error del servidor: " + response.getStatusCode() + " " + response.getStatusText());
            //}

            if (returnType.equals(Void.class)) {
                return null;
            }

            var responseBody = response.getBody()
                    .map(b -> {
                        try {
                            return b.asRawString(StandardCharsets.UTF_8);
                        } catch (IOException e) {
                            throw new RuntimeException("Error al processar el cos de la resposta", e);
                        }
                    })
                    .orElse("{}");

            return mapper.readValue(responseBody, returnType);

        } catch (SocketTimeoutException e) {
            throw new RequestException("Temps d'espera superat en la resposta del servidor.");
        } catch (IOException e) {
            throw new ConsoleClientException("Error de connexió: " + e.getMessage());
        } catch (Exception e) {
            throw new RequestException("Error al processar la sol·licitud: " + e.getMessage());
        }
    }
}
