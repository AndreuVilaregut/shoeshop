package cat.uvic.teknos.shoeshop.clients.utils;


import cat.uvic.teknos.shoeshop.models.*;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import cat.uvic.teknos.shoeshop.clients.dto.*;

public class Mappers {
    private static final ObjectMapper mapper;

    static  {
        mapper = new ObjectMapper();
        mapper
                .registerModule(new JavaTimeModule()) // Registered to map LocalDate (add implementation("com.fasterxml.jackson.datatype:jackson-datatype-jsr310:2.18.0" to build.gradle.kts) )
                .registerModule(
                        new SimpleModule()
                                .addAbstractTypeMapping(Address.class, AddressDto.class)
                ).registerModule(
                        new SimpleModule()
                                .addAbstractTypeMapping(Client.class, ClientDto.class)

                ).registerModule(
                        new SimpleModule()
                                .addAbstractTypeMapping(Inventory.class, InventoryDto.class)
                ).registerModule(
                        new SimpleModule()
                                .addAbstractTypeMapping(Model.class, ModelDto.class)
                )
                .registerModule(
                        new SimpleModule()
                                .addAbstractTypeMapping(Shoe.class, ShoeDto.class)
                ).registerModule(
                        new SimpleModule()
                                .addAbstractTypeMapping(ShoeStore.class, ShoeStoreDto.class)
                ).registerModule(
                        new SimpleModule()
                                .addAbstractTypeMapping(Supplier.class, SupplierDto.class)
                );
    }

    public static ObjectMapper get() {
        return mapper;
    }
}