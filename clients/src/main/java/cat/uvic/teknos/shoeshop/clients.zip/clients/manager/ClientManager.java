package cat.uvic.teknos.shoeshop.clients.manager;

import cat.uvic.teknos.shoeshop.clients.dto.ClientDto;
import cat.uvic.teknos.shoeshop.clients.dto.AddressDto;
import cat.uvic.teknos.shoeshop.clients.dto.ShoeStoreDto;
import cat.uvic.teknos.shoeshop.clients.utils.Mappers;
import cat.uvic.teknos.shoeshop.clients.utils.RestClient;
import cat.uvic.teknos.shoeshop.clients.exceptions.RequestException;
import cat.uvic.teknos.shoeshop.models.Address;
import cat.uvic.teknos.shoeshop.models.ShoeStore;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.List;

public class ClientManager {
    private final RestClient restClient;
    private final BufferedReader in;

    public ClientManager(RestClient restClient, BufferedReader in) {
        this.restClient = restClient;
        this.in = in;
    }

    public void start() throws IOException {
        String command = "";
        do {
            showMenu();
            command = in.readLine();

            switch (command) {
                case "1" -> listClients();
                case "2" -> getClientById();
                //case "3" -> createClient();
                case "4" -> updateClient();
                case "5" -> deleteClient();
            }
        } while (!command.equalsIgnoreCase("exit"));
    }

    private void showMenu() {
        System.out.println("\n*** Client Management ***");
        System.out.println("1. List all clients");
        System.out.println("2. Get client by ID");
        System.out.println("3. Create a new client");
        System.out.println("4. Update an existing client");
        System.out.println("5. Delete a client");
        System.out.println("Type 'exit' to return to the main menu.");
    }

    private void listClients() {
        try {
            var clients = restClient.getAll("/client", ClientDto[].class);
            if (clients.length == 0) {
                System.out.println("No clients found.");
                return;
            }
            for (var client : clients) {
                System.out.println(client);
            }
        } catch (RequestException e) {
            System.out.println("Error fetching clients: " + e.getMessage());
        }
    }

    private void getClientById() throws IOException {
        System.out.print("Enter client ID: ");
        String id = in.readLine();
        try {
            var client = restClient.get("/client/" + id, ClientDto.class);
            System.out.println(client);
        } catch (RequestException e) {
            System.out.println("Error fetching client: " + e.getMessage());
        }
    }


    private void updateClient() throws IOException {
        System.out.print("Enter ID of the client to update: ");
        String id = in.readLine();

        try {
            var existingClient = restClient.get("/client/" + id, ClientDto.class);
            System.out.println("Editing client: " + existingClient);

            System.out.print("Enter new Name (leave blank to keep current): ");
            String name = in.readLine();
            if (!name.isBlank()) existingClient.setName(name);

            System.out.print("Enter new Phone (leave blank to keep current): ");
            String phone = in.readLine();
            if (!phone.isBlank()) existingClient.setPhone(phone);

            restClient.put("/client/" + id, Mappers.get().writeValueAsString(existingClient));
            System.out.println("Client updated successfully.");
        } catch (RequestException e) {
            System.out.println("Error updating client: " + e.getMessage());
        }
    }

    private void deleteClient() throws IOException {
        System.out.print("Enter ID of the client to delete: ");
        String id = in.readLine();

        try {
            restClient.delete("/client/" + id, null);
            System.out.println("Client deleted successfully.");
        } catch (RequestException e) {
            System.out.println("Error deleting client: " + e.getMessage());
        }
    }

    private int createAddress() throws IOException {
        System.out.print("Enter Address details (Street): ");
        String street = in.readLine();
        System.out.print("Enter City: ");
        String city = in.readLine();
        System.out.print("Enter Postal Code: ");
        String postalCode = in.readLine();

        var address = new AddressDto();
        address.setLocation(street);

        try {
            restClient.post("/address", Mappers.get().writeValueAsString(address));
            // Assuming the server returns the created address with the ID.
            return address.getId();
        } catch (RequestException e) {
            System.out.println("Error creating address: " + e.getMessage());
            throw new IOException("Failed to create address.");
        }
    }

    private int createShoeStore() throws IOException {
        System.out.print("Enter Shoe Store Name: ");
        String name = in.readLine();

        var shoeStore = new ShoeStoreDto();
        shoeStore.setName(name);

        try {
            restClient.post("/shoestore", Mappers.get().writeValueAsString(shoeStore));
            // Assuming the server returns the created shoe store with the ID.
            return shoeStore.getId();
        } catch (RequestException e) {
            System.out.println("Error creating shoe store: " + e.getMessage());
            throw new IOException("Failed to create shoe store.");
        }
    }
}
