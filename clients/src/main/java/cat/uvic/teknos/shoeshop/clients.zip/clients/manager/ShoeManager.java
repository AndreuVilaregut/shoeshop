package cat.uvic.teknos.shoeshop.clients.manager;

public class ShoeManager {
}
