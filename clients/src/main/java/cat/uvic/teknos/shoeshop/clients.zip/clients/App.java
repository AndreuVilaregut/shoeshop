package cat.uvic.teknos.shoeshop.clients;

import cat.uvic.teknos.shoeshop.clients.manager.ClientManager;
import cat.uvic.teknos.shoeshop.clients.manager.ShoeManager;
import cat.uvic.teknos.shoeshop.clients.manager.ShoeStoreManager;
import cat.uvic.teknos.shoeshop.clients.utils.RestClientImpl;
import cat.uvic.teknos.shoeshop.clients.exceptions.RequestException;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.util.Properties;

public class App {

    private static final BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
    private static final PrintStream out = System.out;
    private static RestClientImpl restClient;

    static {
        try {
            Properties properties = new Properties();
            var propertiesStream = App.class.getResourceAsStream("/app.properties");
            if (propertiesStream == null) {
                throw new IOException("Error: No s'ha trobat el fitxer de configuració 'app.properties'.");
            }
            properties.load(propertiesStream);

            // Carregar configuració del servidor
            String host = properties.getProperty("server.host", "localhost");
            int port = Integer.parseInt(properties.getProperty("server.port", "9998"));
            restClient = new RestClientImpl(host, port);

        } catch (Exception e) {
            throw new RuntimeException("Error al inicialitzar l'aplicació: " + e.getMessage(), e);
        }
    }

    public static void main(String[] args) throws IOException {
        showWelcomeMessage();

        String command;
        do {
            showMainMenu();
            command = IOUtils.readLine(in);  // Usar IOUtils.readLine() para leer la entrada

            switch (command) {
                case "1" -> new ClientManager(restClient, in).start();
                default -> {
                    if (!command.equalsIgnoreCase("exit")) {
                        out.println("Opció invàlida. Torna-ho a provar.");
                    }
                }
            }
        } while (!command.equalsIgnoreCase("exit"));

        out.println("\n*** Programa tancat correctament ***\n");
    }

    private static void showWelcomeMessage() {
        out.println("\n*** Benvinguts a ShoeShop Back Office ***\n");
    }

    private static void showMainMenu() {
        out.println("\n*** Menú Principal ***\n");
        out.println("1. Gestionar Clients");
        out.println("2. Gestionar Shoes");
        out.println("3. Gestionar Shoe Stores");
        out.println("\nEscriu 'exit' per acabar el programa.");
    }
}
